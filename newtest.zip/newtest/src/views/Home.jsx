import React, { Component } from "react";
import { Grid, Row, Col } from "react-bootstrap";
// import { useHistory } from "react-router-dom";
import { withRouter } from 'react-router-dom';
import { UserCard } from "../components/UserCard/UserCard.jsx";

import avatar from "../assets/img/faces/face-3.jpg";

class Home extends Component {
  constructor(props) {
    super(props);
    this.state = {
      question: ''
    };
    this.routeChange = this.routeChange.bind(this);
  }

  routeChange() {
    let path = `chat`;
    this.props.history.push(path);
  }

  myChangeHandler = (event) => {
    this.setState({question: event.target.value});
  }

  sendQuestion = () => {
    localStorage.setItem('homequestion',this.state.question)
    this.setState({
      question: ""
    })
    this.routeChange();
  }
  
  render() {
    return (
      <div className="content">
        <Grid fluid>
        <UserCard
                bgImage="https://ununsplash.imgix.net/photo-1431578500526-4d9613015464?fit=crop&fm=jpg&h=300&q=75&w=400"
                avatar={avatar}
                description = {
                  `Hi Mohit Tripathi, Welcome to the FLEbot. I am your virtual assistant to help you with
                  queries around content and information. For access issues please refer ##`
                }
                />
          <div className="col-sm-12 home-chat-question">
            <div className="query-title">Type your query here</div>
            <br/>
              <div className="col-sm-11">
                <input type="text" placeholder="Type a question" 
                  className="form-control"
                  value={this.state.question} 
                  onChange={this.myChangeHandler}/>
              </div>
              <div className="col-sm-1">
              <button type="button" class="btn btn-info btn-fill"
                onClick={this.sendQuestion}>Send</button>
              </div>
              <div className="col-sm-12 ">
              <br/>
                <div className="query-title">Frequently asked questions</div>
              <br/>
                {/* <div className="col-sm-4 asked-question-block">More than one EAR application found in the same drop location</div> */}
                <div className="col-sm-4 asked-question-block">No valid artifact directory found</div>
                <div className="col-sm-4 asked-question-block">Build failing on checkmarx step</div>
                
              </div>
            </div>
          </Grid>
      </div>
    );
  }
}

export default Home;
